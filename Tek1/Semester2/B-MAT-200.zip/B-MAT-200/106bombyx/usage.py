def usage():
    print ("USAGE",'\n','\t',"./106bombyx n [k | i0 i1]",'\n')
    print ("DESCRIPTION",'\n',
            '\t',"n",'\t',"number of first generation individuals",'\n',
            '\t',"k",'\t',"growth rate from 1 to 4",'\n',
            '\t',"i0",'\t',"initial generation (included)",'\n',
            '\t',"i1",'\t',"final generation (included)")